/** GPL >= 2.0
 * Based upon jtReversi game written by Jataka Ltd.
 *
 * This software was modified 2008-12-09.  The original file was alphabet.c
 * in http://oware.ivorycity.com/.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
// Expand to define logging define
//#define DLOGGING
package net.sf.yinlight.boardgame.oware.game;

import java.util.Vector;
import net.eiroca.j2me.game.tpg.GameMinMax;
import net.eiroca.j2me.game.tpg.GameMove;
import net.eiroca.j2me.game.tpg.GameTable;
import net.eiroca.j2me.game.tpg.TwoPlayerGame;

//#ifdef DLOGGING
import net.sf.jlogmicro.util.logging.Logger;
import net.sf.jlogmicro.util.logging.Level;
//#endif

public final class OwareAI {

	final public static int MAXDEPTH     = 16;
	final public static int ENDGAMEDEPTH = 20;
	final public static int  MAX = 1;
	final public static int  MIN = 2;
	final public static int  HEURISTIC_DFLT = 0;
	/* Array of heuristics.  Each elmement is a different skill level. */
  private OwareHeuristic[] heuristics = new OwareHeuristic[256];
  private int gheuristic;
  private int gdepth;

	//#ifdef DLOGGING
	private Logger logger = Logger.getLogger("OwareAI");
	private boolean fineLoggable = logger.isLoggable(Level.FINE);
	private boolean finestLoggable = logger.isLoggable(Level.FINEST);
	//#endif

	public OwareAI(int heuristic, int depth) {
		heuristics[0] = new DefaultHeuristic();
		heuristics[1] = new DefenseHeuristic();
		this.gdepth = depth;
		this.gheuristic = heuristic;
	}

	void alphabetaSetHeuristic(int id, OwareHeuristic h) {
		heuristics[id] = h;
	}

	int alphabetaPly( int depth, OwareTable table, byte player, OwareGame g,
			int heuristic,
			int  bestmax, int  bestmin, OwareMove bestmove) {

    final GameMove pMoves[] = g.possibleMoves(table, player);
    for (int i = 0; (i < pMoves.length); ++i)
		{
			int result;
			OwareMove mybest = new OwareMove(0,0);

			OwareTable testTable = new OwareTable(table);

			if (!OwareGame.turn(table, player, (OwareMove)pMoves[i], testTable)) {
				continue; /*An illegal move*/
			}

			if( (depth==0) || OwareGame.isGameEnded(testTable)) {
				result = heuristics[heuristic].getResult(player, testTable);
			} else {
				result = alphabetaPly( depth - 1, testTable, player, g, heuristic, bestmax, bestmin,
						mybest);
			}

			// FIX?
			if(player == 0)
			{
				if(result >= bestmin){
					bestmove.setCoordinates(((OwareMove)pMoves[i]).row, ((OwareMove)pMoves[i]).col);
					return bestmin;
				}
				if(result>bestmax) {
					bestmove.setCoordinates(((OwareMove)pMoves[i]).row, ((OwareMove)pMoves[i]).col);
					bestmax = result;
				}
			} else {
				if(result <= bestmax){
					bestmove.setCoordinates(((OwareMove)pMoves[i]).row, ((OwareMove)pMoves[i]).col);
					return bestmax;
				}
				if(result < bestmin) {
					bestmove.setCoordinates(((OwareMove)pMoves[i]).row, ((OwareMove)pMoves[i]).col);
					bestmin = result;
				}
			}
		}

		if (player == 0) {
			return bestmax;
		} else {
			return bestmin;
		}
	}

	OwareMove alphabeta(OwareGame g, byte player) {
		int result;
		OwareMove bestmove = new OwareMove(0, 0);
		OwareTable testTable = new OwareTable(g.rTable);
		result = alphabetaPly( gdepth, testTable, player, g, gheuristic, -GameMinMax.MAX_POINT, GameMinMax.MAX_POINT, bestmove);
		return bestmove;
	}

	public class DefaultHeuristic extends OwareHeuristic {
		public int getResult(byte player, OwareTable table) {
			return table.getPoints((byte)1) - table.getPoints((byte)0);
		}
	}

	public class DefenseHeuristic extends OwareHeuristic {
		public int getResult(byte player, OwareTable table) {
			if (player == 0) {
				return table.getPoints((byte)0) - table.getPoints((byte)1);
			} else {
				return (3 * table.getPoints((byte)1)) - table.getPoints((byte)0);
			}
		}
	}

}
