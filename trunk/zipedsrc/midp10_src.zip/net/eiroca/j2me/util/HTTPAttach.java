package net.eiroca.j2me.util;

public interface HTTPAttach {

  String getMimeType();

  byte[] getData();

}
