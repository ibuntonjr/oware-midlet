/** GPL >= 2.0
	* FIX arc piece shape and size OwareScreen, no vibrate,flashBacklight for 1.0 for GameApp
	* FIX game menu
	* FIX no getGraphics for GameScreen 1.0 for GameScreen
	* FIX no suppress keys for 1.0 for GameApp
 * Based upon jtReversi game written by Jataka Ltd.
 *
 * This software was modified 2008-12-07.  The original file was Reversi.java
 * in mobilesuite.sourceforge.net project.
 *
 * Copyright (C) 2002-2004 Salamon Andras
 * Copyright (C) 2006-2008 eIrOcA (eNrIcO Croce & sImOnA Burzio)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */
// Expand to define test define
//#define DTEST
// Expand to define test ui define
//#define DTESTUI
// Expand to define logging define
//#define DLOGGING
package net.sf.yinlight.boardgame.oware.midlet;

import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.TextField;
import net.eiroca.j2me.app.Application;
import net.eiroca.j2me.app.BaseApp;
import net.eiroca.j2me.game.GameApp;
import net.eiroca.j2me.game.GameScreen;
import net.eiroca.j2me.game.tpg.GameMinMax;
import net.sf.yinlight.boardgame.oware.game.ui.OwareScreen;
import net.sf.yinlight.boardgame.oware.game.OwareGame;
import com.substanceofcode.rssreader.presentation.FeatureForm;


//#ifdef DLOGGING
import net.sf.jlogmicro.util.logging.Logger;
import net.sf.jlogmicro.util.logging.LogManager;
import net.sf.jlogmicro.util.logging.Level;
import net.sf.jlogmicro.util.logging.FormHandler;
import net.sf.jlogmicro.util.logging.RecStoreHandler;
import net.sf.jlogmicro.util.presentation.RecStoreLoggerForm;
//#endif

/**
	* Oware game application.  Handle game options in addition to standard app
	* options on form.  Save options.
	*/ 
public class OwareMIDlet extends GameApp {

  public static short MSG_OFFSET = 0;
  final public static int MSG_NAME = GameApp.MSG_USERDEF + MSG_OFFSET++; // 0
  final public static short MSG_MENU_MAIN_UNDO = (short)(GameApp.MSG_USERDEF + MSG_OFFSET++);
  final public static short MSG_MENU_MAIN_REDO = (short)(GameApp.MSG_USERDEF + MSG_OFFSET++);
  final public static short MSG_MENU_MAIN_LOGGING = (short)(GameApp.MSG_USERDEF + MSG_OFFSET++);
  final public static int MSG_GAMEMODE = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_GAMEMODE1 = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_GAMEMODE2 = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_AILEVEL = GameApp.MSG_USERDEF + MSG_OFFSET++; //A.I. Difficulty
  final public static int MSG_AILEVEL1 = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_AILEVEL2 = GameApp.MSG_USERDEF + MSG_OFFSET++;
	// FIX use messages for numbers
  final public static int MSG_AILEVEL3 = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_AILEVEL4 = GameApp.MSG_USERDEF + MSG_OFFSET++; // 10
  final public static int MSG_NAMEPLAYER1 = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_NAMEPLAYER2 = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_GOODLUCK = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_THINKING = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_INVALIDMOVE = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_WONCOMPUTER = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_HUMANWON = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_PLAYERWON = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_DRAW = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_HUMAN = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_COMPUTER = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_PASS = GameApp.MSG_USERDEF + MSG_OFFSET++;
  final public static int MSG_LEVELPREFIX = GameApp.MSG_USERDEF + MSG_OFFSET++;

  public static final short GA_UNDO = (short)GameApp.GA_USERDEF + 0;
  public static final short GA_REDO = (short)GameApp.GA_USERDEF + 1;
	//#ifdef DLOGGING
  public static final short GA_LOGGING = (short)GameApp.GA_USERDEF + 2;
	//#endif

  public static String[] playerNames;
  private boolean first = true;
  public static int pSpecialReq = BaseApp.NOT_SPECIAL;

  protected ChoiceGroup opPlayers;
  protected ChoiceGroup opLevel;
  protected ChoiceGroup opDept;
	//#ifdef DLOGGING
  protected TextField opLogLevel;
	//#endif

	/* How many human players. */
  public static int gsPlayer = 1;
	/* Skill level. */
  final static public int gsLevelNormal = 1;
  final static public int gsLevelDifficult = 2;
  final static public int gsLevelHard = 3;
  public static int gsLevel = gsLevelDifficult;
	/* Dept.  Number of moves that the AI tests. */
  public static int gsDept = 3;

	//#ifdef DLOGGING
  private boolean fineLoggable;
  private boolean finestLoggable;
	final public LogManager logManager;
	private Logger logger;
	//#endif

  public OwareMIDlet() {
    super();
		//#ifdef DLOGGING
		logManager = LogManager.getLogManager();
		logManager.readConfiguration(this);
		logger = Logger.getLogger(logManager, "OwareMIDlet", null);
		fineLoggable = logger.isLoggable(Level.FINE);
		finestLoggable = logger.isLoggable(Level.FINEST);
		//#endif
    BaseApp.menu = new short[][] {
        {
            GameApp.ME_MAINMENU, GameApp.MSG_MENU_MAIN_CONTINUE, GameApp.GA_CONTINUE, 0
        }, {
            GameApp.ME_MAINMENU, GameApp.MSG_MENU_MAIN_NEWGAME, GameApp.GA_NEWGAME, 1
        }, {
            GameApp.ME_MAINMENU, OwareMIDlet.MSG_MENU_MAIN_UNDO, OwareMIDlet.GA_UNDO, 2
        }, {
            GameApp.ME_MAINMENU, OwareMIDlet.MSG_MENU_MAIN_REDO, OwareMIDlet.GA_REDO, 3
        }, {
            GameApp.ME_MAINMENU, GameApp.MSG_MENU_MAIN_OPTIONS, GameApp.GA_OPTIONS, 4
        }, {
            GameApp.ME_MAINMENU, GameApp.MSG_MENU_MAIN_HELP, GameApp.GA_HELP, 5
        }, {
            GameApp.ME_MAINMENU, GameApp.MSG_MENU_MAIN_ABOUT, GameApp.GA_ABOUT, 6
				//#ifdef DLOGGING
        }, {
            GameApp.ME_MAINMENU, OwareMIDlet.MSG_MENU_MAIN_LOGGING, OwareMIDlet.GA_LOGGING, 6
        }, {
            GameApp.ME_MAINMENU, OwareMIDlet.MSG_MENU_MAIN_LOGGING, OwareMIDlet.GA_LOGGING, 6
				//#endif
        }
    };
    GameApp.hsName = "Oware";
  }

  public void init() {
		//#ifdef DLOGGING
		if (finestLoggable) {logger.finest("init");}
		//#endif
		try {
			super.init();
			OwareMIDlet.playerNames = new String[] {
					BaseApp.messages[OwareMIDlet.MSG_NAMEPLAYER1], BaseApp.messages[OwareMIDlet.MSG_NAMEPLAYER2]
			};
		} catch (Throwable e) {
			e.printStackTrace();
			//#ifdef DLOGGING
			logger.severe("init error", e);
			//#endif
		}
  }

  public GameScreen getGameScreen() {
		//#ifdef DLOGGING
		if (finestLoggable) {logger.finest("getGameScreen");}
		//#endif
		try {
			return new OwareScreen(this);
		} catch (Throwable e) {
			e.printStackTrace();
			//#ifdef DLOGGING
			logger.severe("getGameScreen error", e);
			//#endif
			return null;
		}
  }

  protected Displayable getOptions() {
		try {
			final Form form = new FeatureForm(BaseApp.messages[GameApp.MSG_MENU_MAIN_OPTIONS]);
			opPlayers = new ChoiceGroup(BaseApp.messages[OwareMIDlet.MSG_GAMEMODE], Choice.EXCLUSIVE);
			opPlayers.append(BaseApp.messages[OwareMIDlet.MSG_GAMEMODE1], null);
			opPlayers.append(BaseApp.messages[OwareMIDlet.MSG_GAMEMODE2], null);
			opLevel = new ChoiceGroup(BaseApp.messages[OwareMIDlet.MSG_AILEVEL], Choice.EXCLUSIVE);
			opLevel.append(BaseApp.messages[OwareMIDlet.MSG_AILEVEL1], null);
			opLevel.append(BaseApp.messages[OwareMIDlet.MSG_AILEVEL2], null);
			opLevel.append(BaseApp.messages[OwareMIDlet.MSG_AILEVEL3], null);
			/* FIX
			opLevel.append(BaseApp.messages[OwareMIDlet.MSG_AILEVEL4], null);
			*/
			opDept = new ChoiceGroup(BaseApp.messages[OwareMIDlet.MSG_AILEVEL],
			//#ifdef DMIDP20
					Choice.POPUP
			//#else
//@					Choice.EXCLUSIVE
			//#endif
					);
			for (int i = 1; i <= 14; i++) {
				opDept.append(Integer.toString(i), null);
			}
			//#ifdef DLOGGING
			opLogLevel = new TextField("Logging level",
							logger.getParent().getLevel().getName(), 20, TextField.ANY);
			//#endif
			form.append(opPlayers);
			form.append(opLevel);
			form.append(opDept);
			//#ifdef DLOGGING
			form.append(opLogLevel);
			//#endif
			BaseApp.setup(form, BaseApp.cBACK, BaseApp.cOK);
			return form;
		} catch (Throwable e) {
			e.printStackTrace();
			//#ifdef DLOGGING
			logger.severe("getOptions error", e);
			//#endif
			return null;
		}
  }

  public void doShowOptions() {
		//#ifdef DLOGGING
		if (finestLoggable) {logger.finest("doShowOptions");}
		//#endif
		try {
			super.doShowOptions();
			opPlayers.setSelectedIndex(OwareMIDlet.gsPlayer - 1, true);
			opLevel.setSelectedIndex(OwareMIDlet.gsLevel - 1, true);
			opDept.setSelectedIndex(OwareMIDlet.gsDept - 1, true);
			//#ifdef DLOGGING
			opLogLevel.setString(
							logger.getParent().getLevel().getName());
			//#endif
		} catch (Throwable e) {
			e.printStackTrace();
			//#ifdef DLOGGING
			logger.severe("doShowOptions error", e);
			//#endif
		}
  }

	//#ifdef DLOGGING
  /**
   * Show is in the record store log file.
	 * FIX do other loggers.
	 *
   * @author Irv Bunton
   */
  public void doShowLogging() {
		if (finestLoggable) {logger.finest("doShowLogging");}
		try {
			Form logf = new RecStoreLoggerForm(logManager, this, BaseApp.midlet);
			BaseApp.setup(logf, BaseApp.cBACK, null);
			BaseApp.show(null, logf, true);
		} catch (Throwable e) {
			e.printStackTrace();
			logger.severe("doShowLogging error", e);
		}
  }
	//#endif

  public void doApplyOptions() {
		//#ifdef DLOGGING
		if (finestLoggable) {logger.finest("doApplyOptions");}
		//#endif
		try {
			OwareMIDlet.gsPlayer = opPlayers.getSelectedIndex() + 1;
			OwareMIDlet.gsLevel = opLevel.getSelectedIndex() + 1;
			OwareMIDlet.gsDept = opDept.getSelectedIndex() + 1;
			((OwareScreen) GameApp.game).updateSkillInfo();
			//#ifdef DLOGGING
			String logLevel = opLogLevel.getString().toUpperCase();
			logger.getParent().setLevel(Level.parse(logLevel));
			//#endif
			super.doApplyOptions();
		} catch (Throwable e) {
			e.printStackTrace();
			//#ifdef DLOGGING
			logger.severe("doApplyOptions error", e);
			//#endif
		}
  }

  public void doGameAbort() {
		//#ifdef DLOGGING
		if (finestLoggable) {logger.finest("doGameAbort");}
		//#endif
		try {
			super.doGameAbort();
			GameMinMax.cancel(false);
			GameMinMax.clearPrecalculatedMoves();
		} catch (Throwable e) {
			e.printStackTrace();
			//#ifdef DLOGGING
			logger.severe("doGameAbort error", e);
			//#endif
		}
  }

	public List getGameMenu() {
		byte[] bsavedRec = null;
		if (first) {
			first = false;
			bsavedRec = ((OwareScreen)game).getSavedGameRecord();
		}
		//#ifdef DLOGGING
		if (finestLoggable) {logger.finest("getGameMenu bsavedRec=" + bsavedRec);}
		//#endif
		List gameMenu = Application.getMenu(GameApp.game.name, GameApp.ME_MAINMENU, GameApp.GA_CONTINUE, BaseApp.cEXIT);
		pSpecialReq = BaseApp.pSpecial;
		if (bsavedRec != null) {
			((OwareScreen)game).bsavedRec = bsavedRec;
			Application.insertMenuItem(gameMenu, BaseApp.pSpecial, BaseApp.menu[BaseApp.pSpecial]);
		}
		return gameMenu;
	}

  protected void prepContinue() {
			if (BaseApp.pSpecial == BaseApp.NOT_SPECIAL) {
				BaseApp.pSpecial = pSpecialReq;
				Application.insertMenuItem(gameMenu, BaseApp.pSpecial, BaseApp.menu[BaseApp.pSpecial]);
			}
	}

  public void processGameAction(final int action) {
		try {
			//#ifdef DLOGGING
			if (finestLoggable) {logger.finest("processGameAction action=" + action);}
			//#endif
			switch (action) {
				case GA_STARTUP: // Continue
					doStartup();
					break;
				case GA_CONTINUE: // Continue
					doGameResume();
					break;
				case GA_NEWGAME: // New game
					doGameStart();
					break;
				case GA_OPTIONS:
					doShowOptions();
					break;
				case GA_HELP:
					doHelp();
					break;
				case GA_ABOUT:
					doAbout();
					break;
				case GA_APPLYOPTIONS:
					doApplyOptions();
					break;
					//#ifdef DLOGGING
				case GA_LOGGING:
					doShowLogging();
					break;
					//#endif
				default:
					break;
			}
		} catch (Throwable e) {
			e.printStackTrace();
			//#ifdef DLOGGING
			logger.severe("processGameAction error", e);
			//#endif
		}
  }

  /**
   * Game Shutdown
   */
  public void doShutdown() {
  }

}
